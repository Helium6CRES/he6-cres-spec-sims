A package for simulating cres data.

