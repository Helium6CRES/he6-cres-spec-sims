"""
he6_cres_spec_sims
An example python library.
"""

__version__ = "0.1.5"
__author__ = 'William (Drew) Byron'
__description__ = "A package for simulating cres data."

